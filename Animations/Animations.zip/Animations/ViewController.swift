//
//  ViewController.swift
//  Animations
//
//  Created by Kenny on 4/14/20.
//  Copyright © 2020 Hazy Studios. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //MARK: - Properties -
    var animationLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        createLabel()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        animationLabel.center = view.center
    }

    private func createLabel() {
        animationLabel = UILabel(frame: CGRect(x:0, y:0, width: 200, height: 200))
        animationLabel.translatesAutoresizingMaskIntoConstraints = false
        animationLabel.text = "🏄🏼‍♂️"
        animationLabel.textAlignment = .center
        animationLabel.font = UIFont.systemFont(ofSize: 96)
        view.addSubview(animationLabel)
    }


}

